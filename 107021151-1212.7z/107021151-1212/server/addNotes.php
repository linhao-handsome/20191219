<?php
include("db_conn.php");
date_default_timezone_set('Asia/Taipei');
$userEmail = $_POST['userEmail'];
$type = $_POST['noteType'];
$title = $_POST['title'];
$description = $_POST['description'];


// $userEmail = $_GET['userEmail'];
// $type = $_GET['noteType'];
// $title =$_GET['title'];
// $description = $_GET['description'];

$sql = "INSERT INTO `note1` (`userEmail`, `type`, `title`, `description`) VALUES ('$userEmail', '$type', '$title', '$description')";
$rv = mysqli_query($link, $sql);
if($rv == false){
    $outData = array("status" => "fail");
}else{
    $outData = array("status" => "success");
}

echo json_encode($outData, JSON_UNESCAPED_UNICODE);
// http://210.70.80.21/~s107021151/addNotes.php?userName=abc&noteType=work&title=123&description=11